<?php ini_set('display_errors', 'On'); require_once('../colorcall.php'); 
$address = $_GET['address']; $unspentList = listUnspent($address); 
$unspCount = count($unspentList); for ($i =0; $i < $unspCount; $i++){
	$txid = $unspentList[$i]['txid'];
	$blockchainInfo = detailedTX($txid);
	$blockchainInfo = json_decode($blockchainInfo, true);
	$output[$i]['hash'] = $unspentList[$i]['txid'];
	$output[$i]['block_hash'] = $blockchainInfo['block_hash'];
	$output[$i]['block_time']=$blockchainInfo['received'];
	$inputCount = count ($blockchainInfo['inputs']);
	for ($j = 0; $j < $inputCount; $j++){
		$output[$i]['inputs'][$j]['transaction_hash'] = $unspentList[$i]['txid'];
		$output[$i]['inputs'][$j]['output_hash'] = $blockchainInfo['inputs'][$j]['prev_hash'];
		$output[$i]['inputs'][$j]['output_index'] = $blockchainInfo['inputs'][$j]['output_index'];
		$output[$i]['inputs'][$j]['value'] = $blockchainInfo['inputs'][$j]['output_value']*100000;
		$blockCount = count($blockchainInfo['inputs'][$j]['addresses']);
		
		for ($k =0; $k < $blockCount; $k++){
			$output[$i]['inputs'][$j]['addresses'][$k] = 
$blockchainInfo['inputs'][$j]['addresses'][$k];
		}
}	
	
	
	$outputCount = count ($blockchainInfo['outputs']);
	for ($j = 0; $j < count($blockchainInfo['outputs']); $j++){
		$output[$i]['outputs']['transaction_hash'] = $unspentList[$i]['txid'];
		$output[$i]['outputs']['index'] = $j;
		$output[$i]['outputs']['value'] = $blockchainInfo['outputs'][$j]['value']*100000000;
		$outputCount = count($blockchainInfo['outputs'][$j]['addresses']);
		for ($k=0; $k < $outputCount; $k++){
			$output[$i]['outputs']['addresses'][$k] = 
$blockchainInfo['outputs'][$j]['addresses'][$k];
		}
		
		$output[$i]['outputs']['script'] = $unspentList[$i]['script'];
		$output[$i]['outputs']['asset_id'] = $unspentList[$i]['asset_id'];
		$output[$i]['outputs']['asset_quantity'] = ($unspentList[$i]['amount'] * 100000000);
	
	
	}
	$output[$i]['amount']=$blockchainInfo['total'];
	$output[$i]['fees']=$blockchainInfo['fees'];
	$output[$i]['confirmations']=$blockchainInfo['confirmations'];
}
header('Access-Control-Allow-Origin: http://192.168.253.132/');

header("Content-Type: application/json;charset=utf-8");
    http_response_code(200);

$prepare = json_encode($output); echo $prepare; ?>
