<?php
require_once('../colorcall.php');
header("Content-Type:application/json");
$userAddress = $_GET['address'];
if ($userAddress[0] == 'b'){
	$oaAddy = $userAddress;
	$response = getBalance($userAddress);
	$response = $response[0];

	$liteAddy = $response['address'];
	}
else if ($userAddress[0] == 'L'){
	$liteAddy = $userAddress;
	$response = getBalance($userAddress);
	$response = $response[0];
	$oaAddy = $response['oa_address'];
	}

$reply['address'] = $liteAddy;
$reply['asset_address'] = $oaAddy;

$reply['issueable_asset'] = null;
$reply['balance'] = $response['value']*100000000;
$reply['unconfirmed_balance'] = $response['value']*100000000;

for ($i =0; $i < count($response['assets']); $i++){
	$reply['assets'][$i]['id'] = $response['assets'][$i]['asset_id'];
	$reply['assets'][$i]['balance'] = $response['assets'][$i]['quantity']*100000000;
	$reply['assets'][$i]['unconfirmed_balance'] = $response['value']*100000000;

}

$reply = json_encode($reply);
echo $reply;


?>
