 <?php
 header("Content-Type:application/json");

 $assetID = $_GET['assetid'];
 
 $response['asset_id'] = $assetID;
  $response['metadata_url'] ="none";
 $response['verified_issuer'] =false;
 $response['name'] ="none";

 $response['contact_url'] ="none";
  $response['name_short'] ="none";
 $response['issuer'] ="null";
 $response['description'] ="none";
 $response['description_mime'] ="text/x-markdown; charset=UTF-8";
  $response['type'] ="none";
 $response['name'] ="none";
 $response['divisibility'] =0;
  $response['icon_url'] ="none";
 $response['image_url'] ="none";

 
 $reply = json_encode($response, true);
 
 echo $reply


 
 
 ?>
