<?php
require_once('../colorcall.php');
$assetID = $_POST['asset'];
$to = $_POST['to'];
$amount = $_POST['amount'];
$address = $_POST['address'];
$response = sendAsset($address, $assetID, $to, $amount);
echo $response;
?>
