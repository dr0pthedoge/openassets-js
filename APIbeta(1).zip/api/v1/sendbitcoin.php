<?php
ini_set('display_errors', 'On');
require_once('../colorcall.php');
$to = $_POST['to'];
$amount = $_POST['amount'];
$address = $_POST['address'];
$response = sendLitecoin($address, $amount, $to);
echo $response;
//echo "hi";

?>
