<?php


 $baseURL = "http://localhost:6789"; ini_set('display_errors', 'On'); function sendAsset($from, $asset, 
$to, $amount){
	global $baseURL;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $baseURL.'/sendasset');
	$data = "amount=$amount&asset=$asset&to=$to&address=$from&mode=unsigned&txformat=raw"; //	echo 
$data;
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
  
}
function sendLitecoin($address, $amount, $to){
	global $baseURL;
	$data = "amount=".$amount."&address=".$address."&to=".$to."&mode=unsigned&txformat=raw";
	$ch = curl_init();
	        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_URL, $baseURL.'/sendbitcoin');
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
	}
	function listUnspent($address=null){
	global $baseURL;
	$data = "";
	$ch = curl_init();
		if ($address != null){
		$data = 'address='.$address;
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_URL, $baseURL.'/listunspent');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$result = curl_exec($ch);
	curl_close($ch);
	return json_decode($result, true);
	
}
	
function getBalance($address=null){
	global $baseURL;
	$data = "";
	$ch = curl_init();
	if ($address != null){
		$data = 'address='.$address;
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_URL, $baseURL.'/getbalance');
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$result = curl_exec($ch);
	curl_close($ch);
	return json_decode($result, true);
}
function issueAsset($address, $amount){
	global $baseURL;
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $baseURL.'/issueasset');
	$data = "amount=".$amount."&address=".$address;
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}

function detailedTX($txid){

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://api.blockcypher.com/v1/ltc/main/txs/".$txid."?limit=50&includeHex=true");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
	
}

 ?>
